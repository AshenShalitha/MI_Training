# Endpoint Error Handling Demo

A small, self-contained demo for the **Mediation / Endpoint Error Handling** training topic. It calls the shared **Hospital Service** backend and shows:

1. What happens with **no** error handling in place when that backend goes down (a raw, unhelpful failure).
2. How to configure **timeout / retry / suspend** on the HTTP Connector so a dead backend is handled gracefully instead of being hammered with every incoming request.
3. How to catch the resulting error in a **fault sequence** and return a clean, client-friendly response instead of an internal Synapse fault.


## Project layout

- `src/main/wso2mi/artifacts/local-entries/HospitalServiceConn.xml` — the HTTP Connector connection to the Hospital Service, with error-handling fields configured (see table below).
- `src/main/wso2mi/artifacts/apis/EndpointErrorHandlingDemoAPI.xml` — `POST /appointments/reserve`, calls the connection above, with a `faultSequence` that turns any failure into a clean `503` JSON response.

## The error-handling configuration

These are the fields that matter, all on the `HospitalServiceConn` local entry:

| Field | Value | What it does |
|---|---|---|
| `timeoutDuration` / `timeoutAction` | `5000` / `Fault` | If the backend accepts the connection but never responds, give up after 5s and treat it as a failure (rather than hanging forever). |
| `retryErrorCodes` / `retryCount` / `retryDelay` | `101504,101505` / `2` / `500` | For a connection that **times out** or is **closed mid-request**, retry up to 2 times (500ms apart) before giving up — these are often transient blips. |
| `suspendErrorCodes` | `101503,101500,101501,101506,101507,101508` | For a connection that's **outright refused** (backend process not running) or other serious transport errors, don't bother retrying — mark the endpoint `SUSPENDED` immediately so subsequent requests fail fast instead of each one waiting on a doomed connection attempt. |
| `suspendInitialDuration` / `suspendProgressionFactor` / `suspendMaximumDuration` | `2000` / `2` / `20000` | Stay suspended for 2s, then try again; if it fails again double the wait (4s, 8s, 16s...) up to a 20s cap. Once a request succeeds, the next suspension (if any) starts back at 2s. |

Note: we deliberately put `101503` (connection refused) under `suspendErrorCodes` rather than leaving it unhandled — our reproduction scenario below is a fully-stopped backend, not an intermittent network blip, so immediate suspension is the right call. (Compare this with the official "Endpoint Error Handling" docs' own base example, which leaves `101503` unhandled on purpose to illustrate that nuance.)

The error codes themselves (`101503` = connection failed, `101504`/`101505` = timeout/connection closed, `303001` = endpoint not ready to connect because it's suspended) are the same ones used by classic `<endpoint>` error handling — the HTTP Connector's retry/suspend fields drive the identical underlying mechanism, just exposed through connector config instead of raw `<address>` XML.

## Reproducing the error scenario

**Prerequisites:** the Hospital Service jar (`Shared-Backend-Service/hospital-service/Hospital-Service-JDK11-2.0.0.jar`) and this project built and running on MI (`Build and Run`).

1. **Confirm the happy path.** With the Hospital Service running on port 9090:
   ```bash
   curl -X POST http://localhost:8290/appointments/reserve \
     -H "Content-Type: application/json" \
     -d '{"patient":{"name":"John Doe"},"doctor":"thomas collins","hospital_id":"grandoaks","hospital":"grand oak community hospital"}'
   ```
   → `200 OK` with the reservation details.

2. **Stop the Hospital Service** (close its terminal / kill the process). This is the "endpoint error" we're reproducing — a backend that's simply not there.

3. **Call the API again** (same curl command). You'll get a clean error instead of a raw fault:
   ```json
   {
       "error": "SERVICE_UNAVAILABLE",
       "message": "The hospital booking service is temporarily unavailable. Please try again shortly.",
       "errorCode": "101503",
       "detail": "Error connecting to the back end"
   }
   ```
   with HTTP status `503`. In the MI console you'll see:
   ```
   WARN {EndpointContext} - Endpoint : HospitalServiceConn_INTERNAL_ENDPOINT_REFERENCE ... will be marked SUSPENDED as it failed
   WARN {EndpointContext} - Suspending endpoint : HospitalServiceConn_INTERNAL_ENDPOINT_REFERENCE ... current suspend duration is : 2000ms - Next retry after : ...
   WARN {LogMediator} - Hospital Service call failed - ERROR_CODE: 101503 ERROR_MESSAGE: Error connecting to the back end
   ```

4. **Call it again immediately** (within the suspend window). This time MI doesn't even attempt the network call — it fails fast because the endpoint is already marked `SUSPENDED`:
   ```json
   {
       "error": "SERVICE_UNAVAILABLE",
       "message": "The hospital booking service is temporarily unavailable. Please try again shortly.",
       "errorCode": "303001",
       "detail": "Currently, HTTP endpoint : [ Name : HospitalServiceConn_INTERNAL_ENDPOINT_REFERENCE ] [ State : SUSPENDED ]"
   }
   ```
   This is the whole point of suspension: once a backend is known to be down, don't waste a connection attempt (and the thread that goes with it) on every single incoming request.

5. **Restart the Hospital Service**, wait a couple of seconds for the suspend window to elapse, and call again — it recovers automatically back to `200 OK`, no server restart or manual re-enabling needed.

## Showing "before" live (optional)

To demonstrate what this looks like *without* any of this in place, temporarily:
- Remove the `faultSequence` block from `EndpointErrorHandlingDemoAPI.xml` (or empty it out, matching the pattern used elsewhere in this course's debugging exercises), and
- Reset the local entry's `retryErrorCodes`, `suspendErrorCodes`, `timeoutDuration` etc. to empty/default (see `GrandOakConn.xml` in the `ContentBasedRouteTutorial` project for what "nothing configured" looks like).

Repeat the same steps above — every failed call now returns Synapse's raw default fault output instead of the clean JSON response, and nothing stops repeated requests from each independently trying (and failing) to reach the dead backend. Re-apply the configuration afterward to show the fix.
